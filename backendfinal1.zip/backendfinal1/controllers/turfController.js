const Turf = require("../models/Turf");
const Booking = require("../models/Booking");

// ================== HELPER: PARSE LOCATION ==================
/**
 * Tries to extract a GeoJSON Point from:
 *  1. nearbyLat / nearbyLng fields (GPS)
 *  2. googleMapLink "lat, lng" string (fallback)
 * Returns { type: "Point", coordinates: [lng, lat] } or null.
 */
function parseLocation(body) {
  // PRIMARY: GPS fields
  if (body.nearbyLat && body.nearbyLng) {
    const lat = Number(body.nearbyLat);
    const lng = Number(body.nearbyLng);
    if (!isNaN(lat) && !isNaN(lng)) {
      return { type: "Point", coordinates: [lng, lat] };
    }
  }

  // FALLBACK: googleMapLink "lat, lng"
  if (body.googleMapLink && body.googleMapLink.includes(",")) {
    const parts = body.googleMapLink.split(",").map((v) => Number(v.trim()));
    if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      return { type: "Point", coordinates: [parts[1], parts[0]] };
    }
  }

  return null;
}

// ================== GET ALL TURFS ==================
exports.getTurfs = async (req, res) => {
  try {
    // ✅ Aggregate ratings from reviews collection
    const turfs = await Turf.aggregate([
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "turf",
          as: "reviews",
        },
      },
      {
        $addFields: {
          ratingCount: { $size: "$reviews" },
          averageRating: {
            $cond: [
              { $gt: [{ $size: "$reviews" }, 0] },
              { $avg: "$reviews.rating" },
              null,
            ],
          },
        },
      },
      {
        $project: { reviews: 0 },
      },
    ]);

    res.json(turfs);
  } catch (err) {
    console.error("getTurfs error:", err);
    res.status(500).json({ message: err.message });
  }
};

// ================== GET SINGLE TURF ==================
exports.getTurfById = async (req, res) => {
  try {
    const turf = await Turf.findById(req.params.id);
    if (!turf) {
      return res.status(404).json({ message: "Turf not found" });
    }
    res.json(turf);
  } catch (err) {
    console.error("getTurfById error:", err);
    res.status(500).json({ message: "Failed to fetch turf" });
  }
};

// ================== ADD TURF ==================
exports.addTurf = async (req, res) => {
  try {
    console.log("✅ ADD TURF BODY:", req.body);
    console.log("✅ FILES:", req.files);

    const turfData = {
      name: req.body.name,

      sportType: req.body.sportType
        ? Array.isArray(req.body.sportType)
          ? req.body.sportType
          : [req.body.sportType]
        : [],

      turfSize: req.body.turfSize,
      length: req.body.length ? Number(req.body.length) : undefined,
      width: req.body.width ? Number(req.body.width) : undefined,
      maxCapacity: req.body.maxCapacity
        ? Number(req.body.maxCapacity)
        : undefined,
      description: req.body.description,

      amenities: req.body.amenities ? JSON.parse(req.body.amenities) : [],

      address: req.body.address,
      city: req.body.city,
      state: req.body.state,
      pinCode: req.body.pinCode,
      contactNumber: req.body.contactNumber,
      email: req.body.email,
      googleMapLink: req.body.googleMapLink,

      weekdayPrice: req.body.weekdayPrice
        ? Number(req.body.weekdayPrice)
        : undefined,
      weekendPrice: req.body.weekendPrice
        ? Number(req.body.weekendPrice)
        : undefined,
      minBookingDuration: req.body.minBookingDuration,

      weekdayOpen: req.body.weekdayOpen,
      weekdayClose: req.body.weekdayClose,
      weekendOpen: req.body.weekendOpen,
      weekendClose: req.body.weekendClose,

      // ✅ Map uploaded files to URL paths
      images: req.files?.length
        ? req.files.map((f) => `/uploads/turfs/${f.filename}`)
        : [],
    };

    // ✅ Attach location if parseable
    const location = parseLocation(req.body);
    if (location) turfData.location = location;

    console.log("✅ FINAL LOCATION:", turfData.location);

    const turf = await Turf.create(turfData);
    res.status(201).json(turf);
  } catch (err) {
    console.error("❌ addTurf error:", err);
    res.status(500).json({ message: err.message });
  }
};

// ================== UPDATE TURF ==================
exports.updateTurf = async (req, res) => {
  try {
    const updateData = {};

    const allowedFields = [
      "name",
      "turfSize",
      "length",
      "width",
      "maxCapacity",
      "description",
      "address",
      "city",
      "state",
      "pinCode",
      "contactNumber",
      "email",
      "googleMapLink",
      "weekdayPrice",
      "weekendPrice",
      "minBookingDuration",
      "weekdayOpen",
      "weekdayClose",
      "weekendOpen",
      "weekendClose",
    ];

    allowedFields.forEach((f) => {
      if (req.body[f] !== undefined) updateData[f] = req.body[f];
    });

    if (req.body.amenities) {
      updateData.amenities = JSON.parse(req.body.amenities);
    }

    if (req.body.sportType) {
      updateData.sportType = Array.isArray(req.body.sportType)
        ? req.body.sportType
        : [req.body.sportType];
    }

    // ✅ Append new uploaded images to existing ones (don't overwrite)
    if (req.files?.length) {
      const newImages = req.files.map((f) => `/uploads/turfs/${f.filename}`);
      const existingTurf = await Turf.findById(req.params.id);
      if (!existingTurf) {
        return res.status(404).json({ message: "Turf not found" });
      }
      updateData.images = [...(existingTurf.images || []), ...newImages];
    }

    // ✅ Update location if provided
    const location = parseLocation(req.body);
    if (location) updateData.location = location;

    const turf = await Turf.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
    });

    if (!turf) {
      return res.status(404).json({ message: "Turf not found" });
    }

    res.json(turf);
  } catch (err) {
    console.error("❌ updateTurf error:", err);
    res.status(500).json({ message: err.message });
  }
};

// ================== DELETE TURF ==================
// ================== DELETE TURF ==================
exports.deleteTurf = async (req, res) => {
  try {
    const turfId = req.params.id;

    // ✅ Check if turf exists
    const turf = await Turf.findById(turfId);
    if (!turf) {
      return res.status(404).json({ message: "Turf not found" });
    }

    // ✅ DELETE ALL BOOKINGS FOR THIS TURF
    await Booking.deleteMany({ turf: turfId });

    // ✅ DELETE THE TURF ITSELF
    await Turf.findByIdAndDelete(turfId);

    res.json({
      message: "Turf and all associated bookings deleted successfully",
    });
  } catch (err) {
    console.error("❌ deleteTurf error:", err);
    res.status(500).json({ message: "Failed to delete turf" });
  }
};


// ================== GET NEARBY TURFS ==================
exports.getNearbyTurfs = async (req, res) => {
  try {
    const { lat, lng, distance = 5000 } = req.query;

    if (!lat || !lng) {
      return res
        .status(400)
        .json({ message: "Latitude and longitude required" });
    }

    const latitude = Number(lat);
    const longitude = Number(lng);

    if (isNaN(latitude) || isNaN(longitude)) {
      return res
        .status(400)
        .json({ message: "Invalid latitude or longitude" });
    }

    // ✅ $nearSphere works correctly with a 2dsphere index
    const turfs = await Turf.find({
      location: {
        $nearSphere: {
          $geometry: {
            type: "Point",
            coordinates: [longitude, latitude],
          },
          $maxDistance: Number(distance), // metres
        },
      },
    });

    res.status(200).json(turfs);
  } catch (err) {
    console.error("❌ getNearbyTurfs error:", err);
    res.status(500).json({ message: "Failed to fetch nearby turfs" });
  }
};