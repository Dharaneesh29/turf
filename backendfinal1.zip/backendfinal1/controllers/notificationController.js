const Notification = require("../models/Notification")

exports.getNotifications = async (req, res) => {
    try{
        const notifications = await Notification.find()
        .sort({createdAt: -1})
        .limit(50)
        const unreadCount = await Notification.countDocuments({isRead: false})
        res.json({notifications, unreadCount})
    } catch (err) {
        res.status(500).json({message: err.message})
    }
}

exports.markAsRead = async (req, res) => {
    try{
        await Notification.findByIdAndUpdate(req.params.id, {isRead: true})
        res.json({message: "Marked as read"})
    } catch (err) {
        res.status(500).json({message: err.message})
    }
}

exports.markAllAsRead = async (req, res) => {
    try{
        await Notification.updateMany({isRead: false}, {isRead: true})
        res.json({message: "All marked as read"})
    } catch (err) {
        res.status(500).json({message: err.message})
    }
}

exports.deleteNotification = async (req, res) => {
    try{
        await Notification.findByIdAndDelete(req.params.id)
        res.json({message: "Notification deleted"})
    } catch (err) {
        res.status(500).json({message: err.message})
    }
}

exports.clearAll = async (req, res) => {
    try{
        await Notification.deleteMany({})
        res.json({message: "All notifications cleared"})
    } catch (err) {
        res.status(500).json({message: err.message})
    }
}

exports.createNotification = async ({type, message, link = "", meta = {} }) => {
    try{
        await Notification.create({type, message, link, meta})
    } catch (err) {
        res.status(500).json("Failed to create notification:", err.message)
    }
}