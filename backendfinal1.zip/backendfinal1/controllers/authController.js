const User = require("../models/User");
const bcrypt = require("bcrypt");
const generateToken = require("../utils/generateToken")
const {createNotification} = require("./notificationController")
 
exports.register = async (req, res) => {
  const { name, email, password, role } = req.body;
 
  try {
    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }
 
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }
 
    const hashedPassword = await bcrypt.hash(password, 10);
 
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      role: role || "user",
    });
 
    res.status(201).json({
      message: "Registration successful",
      token: generateToken(user),
    });
 
    await createNotification({
        type: "new_user",
        message: `New user registered - ${user.name}`,
        link: "/admin/users",
        meta: {userId: user._id}
    })
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
exports.login = async (req, res) => {
  const { email, password } = req.body;
 
  try {
    if (!email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }
 
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Invalid email or password" });
    }
 
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid email or password" });
    }
 
    res.status(200).json({
      message: "Login successful",
      token: generateToken(user),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
 