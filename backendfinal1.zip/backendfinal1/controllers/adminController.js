const Turf = require("../models/Turf");
const Booking = require("../models/Booking");
const User = require("../models/User");
const TurfReview = require('../models/Review');
const {createNotification} = require('./notificationController');


/* ======================================================
   ADD TURF (MULTIPLE IMAGES) ✅
====================================================== */
exports.addTurf = async (req, res) => {
  try {
    console.log("req.body:", req.body);
    console.log("req.files:", req.files);

    const images = (req.files || []).map(
      file => `/uploads/turfs/${file.filename}`
    );

    const turf = await Turf.create({
      name: req.body.name,
      sportType: (()=>{
        try {
          if (!req.body.sportType) return [];
          return Array.isArray(req.body.sportType)
            ? req.body.sportType
            : JSON.parse(req.body.sportType);
        } catch {
          return [];
        }
      })(),
      turfSize: req.body.turfSize,
      length: Number(req.body.length) || undefined,
      width: Number(req.body.width) || undefined,
      maxCapacity: Number(req.body.maxCapacity) || undefined,
      description: req.body.description,

      amenities: (() => {
        try {
          if (!req.body.amenities) return [];
          return Array.isArray(req.body.amenities)
            ? req.body.amenities
            : JSON.parse(req.body.amenities);
        } catch {
          return [];
        }
      })(),

      address: req.body.address,
      city: req.body.city,
      state: req.body.state,
      pinCode: req.body.pinCode,
      contactNumber: req.body.contactNumber,
      email: req.body.email,
      googleMapLink: req.body.googleMapLink,

      weekdayPrice: Number(req.body.weekdayPrice) || 0,
      weekendPrice: Number(req.body.weekendPrice) || 0,
      minBookingDuration: req.body.minBookingDuration,

      weekdayOpen: req.body.weekdayOpen,
      weekdayClose: req.body.weekdayClose,
      weekendOpen: req.body.weekendOpen,
      weekendClose: req.body.weekendClose,

      images, // ✅ STORED CORRECTLY
    });

    res.status(201).json(turf);
  } catch (error) {
    console.error("addTurf error:", error);
    res.status(500).json({ message: error.message });
  }
};

/* ======================================================
   GET ALL TURFS ✅
====================================================== */
exports.getTurfs = async (req, res) => {
  try {
    const turfs = await Turf.find().sort({ createdAt: -1 });
    res.json(turfs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* ======================================================
   UPDATE TURF (MULTIPLE IMAGES) ✅
====================================================== */
exports.updateTurf = async (req, res) => {
  try{
    console.log("updateTurf body:", req.body)
    console.log("updateTurf files:", req.files)

    const updateData = {...req.body}
    if (req.body.sportType) {
      try {
        const parsed = JSON.parse(req.body.sportType);
        updateData.sportType = parsed;
        console.log("Sport parsed:", parsed);
      } catch (e) {
        console.log("Sport type parse error:", e.message);
        updateData.sportType = [];
      }
    }
    if (req.body.amenities) {
      try {
        const parsed = JSON.parse(req.body.amenities);
        updateData.amenities = parsed;
        console.log("amenities parsed:", parsed);
      } catch (e) {
        console.log("amenities parse error:", e.message);
        updateData.amenities = [];
      }
    }
 
    ["weekdayPrice", "weekendPrice", "length", "width", "maxCapacity"].forEach((f) => {if(req.body[f]) updateData[f] = Number(req.body[f])})
    if(req.files && req.files.length > 0) {
      updateData.images = req.files.map(
        file => `/uploads/turfs/${file.filename}`
      )
    }

    const turf = await Turf.findByIdAndUpdate(req.params.id, updateData, {new: true})
    if(!turf) res.status(404).json({message: "Turf not found"})
    res.json(turf)
  } catch (err) {
    res.status(500).json({message: err.message})
  }
} 

/* ======================================================
   DELETE TURF ✅
====================================================== */
exports.deleteTurf = async (req, res) => {
  try {

    await Booking.deleteMany({turf:req.params.id})
    await TurfReview.deleteMany({turf: req.params.id})
    await Turf.findByIdAndDelete(req.params.id);
    res.json({ message: "Turf deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* ======================================================
   BOOKINGS & USERS (UNCHANGED)
====================================================== */
exports.getBookings = async (req, res) => {
  const bookings = await Booking.find()
    .populate("user", "name email")
    .populate("turf", "name city weekdayPrice")
    .sort({ createdAt: -1 });

  res.json(bookings);
};

exports.updateBookingStatus = async (req, res) => {
  try{
    const {paymentStatus, status, cancellationReason} = req.body
    const booking = await Booking.findById(req.params.id)
    if(!booking) return res.status(404).json({message: "Booking not found"})
    const updateBooking = await Booking.findByIdAndUpdate(
      req.params.id,
      {
        paymentStatus,
        status,
        ...(cancellationReason && {cancellationReason})
      },
      {new: true}
    ).populate("user", "name email")
    .populate("turf", "name city")

    

      if (req.body.status === "cancelled") {
      await createNotification({
        type:    "booking_cancelled",
        message: `Booking cancelled — ${updateBooking.turf?.name || "Unknown turf"} on ${updateBooking.date}`,
        link:    "/admin/bookings",
        meta:    { bookingId: updateBooking._id },
      });
    }
 
    if (req.body.paymentStatus === "paid") {
      await createNotification({
        type:    "payment_received",
        message: `Payment of ₹${updateBooking.totalAmount} received — ${updateBooking.user?.name || "Unknown user"}`,
        link:    "/admin/payments",
        meta:    { bookingId: updateBooking._id },
      });
    }

    res.json(updateBooking)
  }catch(err){
    res.status(500).json({message:err.message})
  }
}

exports.deleteBooking = async (req, res) => {
  await Booking.findByIdAndDelete(req.params.id);
  res.json({ message: "Booking deleted" });
};

exports.getUsers = async (req, res) => {
    try{
        const users = await User.find()
        .select("-password")
        .sort({createdAt:-1})

        res.json(users)
    } catch {
        res.status(500).json({message: error.message})
    }
}
exports.updateUsers = async (req, res) => {
  try{
    const {isBlocked} = req.body
    const user = await User.findByIdAndUpdate(
      req.params.id,
      {
        isBlocked
      },
      {new: true}
    ).select("-password")

    if(!user) return res.status(404).json({message: "Booking not found"})
    res.json(user)
  }catch(err){
    res.status(500).json({message:err.message})
  }
}

exports.deleteUsers = async (req, res) => {
  try{
    await User.findByIdAndDelete(req.params.id)
    res.json({message: "User deleted successfully"})
  } catch (err) {
    res.status(500).json({message:err.message})
  }
}