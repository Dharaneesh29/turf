const Booking             = require("../models/Booking");
const { createNotification } = require("./notificationController");
const UserMembership      = require("../models/UserMembership");
const Turf                = require("../models/Turf");
const User                = require("../models/User");
const WalletTransaction   = require("../models/walletTransaction");

exports.createBooking = async (req, res) => {
  try {
    const {
      turf,
      date,
      timeSlot,
      duration,
      totalAmount,
      paymentMethod,
      paymentStatus,
      playerCount,
      contactNumber,
      notes,
      sportType,
      discountApplied,
      walletAmountUsed = 0,
    } = req.body;

    // Validate essential fields
    if (!turf || !date || !timeSlot) {
      return res.status(400).json({ message: "Turf, date and time slot are required" });
    }

    const existing = await Booking.findOne({ turf, date, timeSlot });
    if (existing) {
      return res.status(400).json({ message: "This slot is already booked" });
    }

    // Fetch turf price from DB
    const turfData = await Turf.findById(turf);
    if (!turfData) {
      return res.status(404).json({ message: "Turf not found" });
    }

    const pricePerHour = turfData.weekdayPrice ?? turfData.pricePerHour ?? 0;
    const hours        = duration ?? 1;
    let   basePrice    = pricePerHour * hours;
    let   finalPrice   = basePrice;

    // Apply membership discount
    const membership = await UserMembership.findOne({
      user:    req.user.id,
      status:  "active",
      endDate: { $gte: new Date() },
    }).populate("plan");

    if (membership?.plan?.discountPercent) {
      finalPrice = basePrice - (basePrice * membership.plan.discountPercent) / 100;
    }

    // Apply wallet deduction
    const walletUsed = Number(walletAmountUsed) || 0;
    if (walletUsed > 0) {
      // Verify user has enough wallet balance
      const userDoc = await User.findById(req.user.id);
      if (userDoc.walletBalance < walletUsed) {
        return res.status(400).json({ message: "Insufficient wallet balance" });
      }
    }

    const booking = await Booking.create({
      user:            req.user.id,
      turf,
      date,
      timeSlot,
      duration:        hours,
      totalAmount:     totalAmount ?? Math.round(finalPrice),
      paymentMethod:   paymentMethod   ?? "cash",
      paymentStatus:   paymentStatus   ?? "pending",
      playerCount:     playerCount     ?? 1,
      contactNumber:   contactNumber   ?? "",
      notes:           notes           ?? "",
      sportType:       sportType       ?? "",
      discountApplied: discountApplied ?? null,
      walletAmountUsed: walletUsed,
      status:          "pending",
    });

    // Deduct wallet balance if used
    if (walletUsed > 0) {
      await User.findByIdAndUpdate(req.user.id, {
        $inc: { walletBalance: -walletUsed }
      });

      await WalletTransaction.create({
        user:    req.user.id,
        amount:  walletUsed,
        type:    "debit",
        reason:  "Wallet used for booking",
        booking: booking._id,
      });
    }

    // Notifications
    await createNotification({
      type:    "new_booking",
      message: `New booking made for ${date} ${timeSlot}`,
      link:    "/admin/bookings",
      meta:    { userId: req.user.id, bookingId: booking._id },
    });

    if (paymentStatus === "paid") {
      await createNotification({
        type:    "payment_received",
        message: `Payment of ₹${totalAmount} received via ${paymentMethod}`,
        link:    "/admin/payments",
        meta:    { userId: req.user.id, bookingId: booking._id },
      });
    }

    const { io } = require("../index");
    io.emit("slot-updated", { turf, date, timeSlot });

    res.status(201).json(booking);

  } catch (error) {
    console.error("createBooking error:", error.message);
    res.status(500).json({ message: error.message });
  }
};

exports.getUserBookings = async (req, res) => {
  try {
    let bookings = await Booking.find({ user: req.user.id })
      .populate("turf", "name city weekdayPrice image images")
      .sort({ createdAt: -1 });
    bookings = bookings.filter(b => b.turf);
    res.json(bookings);
  } catch (error) {
    console.error("getUserBookings error:", error);
    res.status(500).json({ message: error.message });
  }
};
