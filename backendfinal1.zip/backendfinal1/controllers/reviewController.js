const TurfReview = require("../models/TurfReview");
const Booking = require("../models/Booking");
const Turf = require("../models/Turf");


// ✅ Create Review (only after completed booking)
exports.createReview = async (req, res) => {
  try {
    const { turfId, bookingId, rating, comment } = req.body;

    // ✅ Validate booking
    const booking = await Booking.findOne({
      _id: bookingId,
      user: req.user.id,
      turf: turfId,
      status: "completed",
    });

    if (!booking) {
      return res.status(400).json({
        message: "You can review only after completing a booking",
      });
    }

    const review = await TurfReview.create({
      turf: turfId,
      user: req.user.id,
      booking: bookingId,
      rating,
      comment,
    });

    // ✅ Update turf rating
    const turf = await Turf.findById(turfId);
    const totalRating =
      turf.averageRating * turf.ratingCount + rating;

    turf.ratingCount += 1;
    turf.averageRating = totalRating / turf.ratingCount;

    await turf.save();

    res.status(201).json(review);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


// ✅ Get reviews for a turf
exports.getTurfReviews = async (req, res) => {
  const reviews = await TurfReview.find({
    turf: req.params.turfId,
    isHidden: false,
  })
    .populate("user", "name")
    .sort({ createdAt: -1 });

  res.json(reviews);
};