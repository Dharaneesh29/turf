const Match = require("../models/Match");
const Booking = require("../models/Booking");
const crypto = require("crypto");

// ======================
// CREATE MATCH
// ======================
exports.createMatch = async (req, res) => {
  try {
    const {
      turf,
      date,
      startTime,
      endTime,
      sportType,
      maxPlayers,
      privacy,
      tournament,
    } = req.body;

    const inviteCode =
      privacy === "private"
        ? crypto.randomBytes(6).toString("hex")
        : null;

    // ✅ Auto-book turf slot for host
    await Booking.create({
      user: req.user.id,
      turf,
      date,
      timeSlot: `${startTime} - ${endTime}`,
      status: "confirmed",
    });

    // ✅ Host is auto-added as a registered player
    const match = await Match.create({
      host: req.user.id,
      turf,
      sportType,
      date,
      startTime,
      endTime,
      maxPlayers,
      privacy,
      inviteCode,
      tournament: {
        name: tournament.name,
        level: tournament.level,
        category: tournament.category,
        days: tournament.days,
      },
      players: [{ user: req.user.id }], // ✅ IMPORTANT
    });

    res.status(201).json(match);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ======================
// JOIN BY INVITE (PRIVATE MATCH)
// ======================
exports.joinByInvite = async (req, res) => {
  try {
    const { inviteCode } = req.params;

    const match = await Match.findOne({
      inviteCode,
      privacy: "private",
    });

    if (!match) {
      return res.status(404).json({ message: "Invalid invite code" });
    }

    // Already joined
    if (match.players.some(p => p.user.equals(req.user.id))) {
      return res.json(match);
    }

    // Capacity check
    if (match.players.length >= match.maxPlayers) {
      return res.status(400).json({ message: "Match is full" });
    }

    match.players.push({ user: req.user.id });
    await match.save();

    res.json(match);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ======================
// JOIN MATCH (PUBLIC)
// ======================
exports.joinMatch = async (req, res) => {
  try {
    const { matchId } = req.params;
    const skill = req.body?.skill || "beginner";

    const match = await Match.findById(matchId);
    if (!match) {
      return res.status(404).json({ message: "Match not found" });
    }

    if (match.players.some(p => p.user.equals(req.user.id))) {
      return res.status(400).json({ message: "Already joined" });
    }

    if (match.players.length >= match.maxPlayers) {
      match.status = "full";
      await match.save();
      return res.status(400).json({ message: "Match is full" });
    }

    match.players.push({ user: req.user.id, skill });
    await match.save();

    res.json(match);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ======================
// LEAVE MATCH
// ======================
exports.leaveMatch = async (req, res) => {
  try {
    const { matchId } = req.params;
    const match = await Match.findById(matchId);

    if (!match) {
      return res.status(404).json({ message: "Match not found" });
    }

    // Remove user from players
    match.players = match.players.filter(
      p => !p.user.equals(req.user.id)
    );

    match.status = "open";
    await match.save();

    res.json(match);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ======================
// GET PUBLIC MATCHES (BROWSE)
// ======================
exports.getMatches = async (req, res) => {
  const now = new Date();

  const matches = await Match.find({ privacy: "public" })
    .populate("host", "name")
    .populate("turf", "name city")
    .sort({ date: 1 });

  const activeMatches = matches.filter(m => {
    const endDateTime = new Date(`${m.date}T${m.endTime}`);
    return endDateTime > now; // ✅ show upcoming only
  });

  res.json(activeMatches);
};

// ======================
// GET MATCH BY ID
// ======================
exports.getMatchById = async (req, res) => {
  try {
    const match = await Match.findById(req.params.matchId)
      .populate("host", "name email")
      .populate("turf", "name city")
      .populate("players.user", "name");

    if (!match) {
      return res.status(404).json({ message: "Match not found" });
    }

    res.json(match);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ======================
// ✅ GET MY MATCHES (REGISTERED ONLY)
// ======================
exports.getMyMatches = async (req, res) => {
  try {
    const userId = req.user.id;

    // ✅ ONLY matches the user has REGISTERED (joined)
    const matches = await Match.find({
      "players.user": userId,
    })
      .populate("host", "name")
      .populate("turf", "name city")
      .select(
        "date startTime endTime sportType tournament players maxPlayers privacy"
      )
      .sort({ date: 1 });

    res.json(matches);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch registered matches" });
  }
};
