const MembershipPlan = require("../models/MembershipPlan");
const UserMembership = require("../models/UserMembership");

/**
 * ✅ GET all active plans (User view)
 */
exports.getPlans = async (req, res) => {
  try {
    const plans = await MembershipPlan.find({ isActive: true });
    res.json(plans);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch plans" });
  }
};

/**
 * ✅ ACTIVATE membership (after payment)
 */
exports.activateMembership = async (req, res) => {
  try {
    const { planId } = req.body;

    if (!planId) {
      return res.status(400).json({ message: "Plan ID is required" });
    }

    const plan = await MembershipPlan.findById(planId);
    if (!plan || !plan.isActive) {
      return res.status(404).json({ message: "Plan not found or inactive" });
    }

    // ✅ Prevent multiple active memberships
    const existing = await UserMembership.findOne({
      user: req.user.id,
      status: "active",
      endDate: { $gte: new Date() },
    });

    if (existing) {
      return res.status(400).json({
        message: "You already have an active membership",
      });
    }

    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.durationDays);

    const membership = await UserMembership.create({
      user: req.user.id,
      plan: plan._id,
      startDate,
      endDate,
      status: "active",
      remainingBookings: plan.maxBookingsPerWeek ?? null,
    });

    res.status(201).json(membership);
  } catch (err) {
    console.error("activateMembership error:", err);
    res.status(500).json({ message: "Failed to activate membership" });
  }
};

/**
 * ✅ GET logged-in user's active membership
 */
exports.getMyMembership = async (req, res) => {
  try {
    const membership = await UserMembership.findOne({
      user: req.user.id,
      status: "active",
      endDate: { $gte: new Date() },
    }).populate("plan");

    res.json(membership);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch membership" });
  }
};

/**
 * ✅ ADMIN: Create membership plan
 */
exports.createPlan = async (req, res) => {
  try {
    const {
      name,
      type,
      price,
      durationDays,
      discountPercent,
      maxBookingsPerWeek,
      allowedHours,
    } = req.body;

    // ✅ Validate required fields
    if (!name || !price || !durationDays) {
      return res.status(400).json({
        message: "Name, price and duration are required",
      });
    }

    const plan = await MembershipPlan.create({
      name,
      type,
      price,
      durationDays,
      discountPercent: discountPercent ?? 0,
      maxBookingsPerWeek: maxBookingsPerWeek ?? null,
      allowedHours: allowedHours ?? [],
      isActive: true, // ✅ IMPORTANT
    });

    res.status(201).json(plan);
  } catch (err) {
    console.error("createPlan error:", err);
    res.status(400).json({ message: err.message });
  }
};

/**
 * ✅ ADMIN: Update plan (toggle active / edit)
 */
exports.updatePlan = async (req, res) => {
  try {
    const plan = await MembershipPlan.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!plan) {
      return res.status(404).json({ message: "Plan not found" });
    }

    res.json(plan);
  } catch (err) {
    res.status(400).json({ message: "Failed to update plan" });
  }
};


exports.deletePlan = async(req, res) => {
  try{
    const plan = await MembershipPlan.findByIdAndDelete(req.params.id)
    if(!plan) return res.status(404).json({message: "Plan not found"})
    res.json({message: "Plan deleted successfully"})
  }catch(err){
    res.status(500).json({message: err.message})
  }
}
