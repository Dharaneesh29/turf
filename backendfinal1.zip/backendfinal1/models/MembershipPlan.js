const mongoose = require("mongoose");

const membershipPlanSchema = new mongoose.Schema({
  name: String,
  type: {
    type: String,
    enum: ["weekly", "monthly", "yearly", "corporate"],
  },
  price: Number,
  durationDays: Number,
  discountPercent: Number,
  allowedHours: [String], // optional
  maxBookingsPerWeek: Number,
  isActive: { type: Boolean, default: true },
});

module.exports = mongoose.model("MembershipPlan", membershipPlanSchema);
