const mongoose = require("mongoose")
 
const notificationSchema = new mongoose.Schema(
    {
        type: {
            type: String,
            enum: ["new_booking", "booking_cancelled", "payment_received", "new_user"],
            required: true
        },
        message: {type: String, required: true},
        isRead: {type: Boolean, default:false},
        link: {type: String, default:""},
        meta: {
            userId: {type: mongoose.Schema.Types.ObjectId, ref: "User"},
            userId: {type: mongoose.Schema.Types.ObjectId, ref: "booking"},
        }
    },
    {timestamps: true}
)
 
module.exports = mongoose.models.Notification || mongoose.model("Notification", notificationSchema)