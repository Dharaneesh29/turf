const mongoose = require('mongoose')

const UserSchema = new mongoose.Schema({
  name:      { type: String, required: true, trim: true },
  email:     { type: String, unique: true, lowercase: true, trim: true },
  password:  { type: String, required: true },
  role:      { type: String, enum: ['user', 'admin'], default: 'user' },
  dob:       { type: String, default: "" },
  phone:     { type: String, trim: true, default: "" },
  isBlocked: { type: Boolean, default: false },
  favourites: [{ type: mongoose.Schema.Types.ObjectId, ref: "Turf" }],
  walletBalance:{type:Number,default:0},// new line
}, { timestamps: true })

module.exports = mongoose.model('User', UserSchema)
