const mongoose = require("mongoose");
 
const bookingSchema = new mongoose.Schema(
  {
    // References
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    turf: { type: mongoose.Schema.Types.ObjectId, ref: "Turf", required: true },
 
    // Booking details
    date:     { type: String, required: true }, // "2026-04-10"
    timeSlot: { type: String, required: true }, // "6AM - 7AM"
    duration: { type: Number, default: 1 },     // in hours
    sportType: {type: String, default: ""},
 
    // Payment
    totalAmount:     { type: Number, default: 0 },
    paymentStatus:   { type: String, enum: ["pending", "paid", "failed", "refunded"], default: "pending" },
    paymentMethod:   { type: String, enum: ["cash", "upi", "card", "wallet"], default: "cash" },
    transactionId:   { type: String, default: "" },
    walletAmountUsed: {type:Number,default:0},
    discountApplied:{type:String,default:null},
 
    // Booking status
    status: {
      type: String,
      enum: ["pending", "confirmed", "cancelled", "completed"],
      default: "pending"
    },
 
    // Extra
    cancellationReason: { type: String, default: "" },
    notes:              { type: String, default: "" },
  },
  { timestamps: true }
);
 
module.exports = mongoose.model("Booking", bookingSchema);
 