const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
  {
    match: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Match",
      required: true,
    },
    senderName: {
      type: String,
      required: true,
    },
    message: {
      type: String,
      
      required: true,
    },
  },
  { timestamps: true } // ✅ createdAt, updatedAt
);

module.exports = mongoose.model("Message", messageSchema);