const mongoose = require("mongoose");

const userMembershipSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  plan: { type: mongoose.Schema.Types.ObjectId, ref: "MembershipPlan" },

  startDate: Date,
  endDate: Date,

  status: {
    type: String,
    enum: ["active", "expired", "cancelled"],
    default: "active",
  },

  remainingBookings: Number,
});

module.exports = mongoose.model("UserMembership", userMembershipSchema);