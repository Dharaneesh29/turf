const mongoose = require("mongoose");

const matchSchema = new mongoose.Schema(
  {
    host: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    turf: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Turf",
      required: true,
    },

    sportType: {
      type: String,
      required: true,
    },

    date: {
      type: String, // YYYY-MM-DD
      required: true,
    },

    startTime: {
      type: String, // HH:mm
      required: true,
    },

    endTime: {
      type: String, // HH:mm
      required: true,
    },

    tournament: {
      name: { type: String, required: true },
      level: {
        type: String,
        enum: ["district", "state", "national"],
        required: true,
      },
      category: {
        type: String,
        enum: ["open", "u15", "u18", "u21", "corporate", "women", "men", "mixed"],
        required: true,
      },
      days: { type: Number, min: 1, required: true },
    },

    privacy: {
      type: String,
      enum: ["public", "private"],
      default: "public",
    },

    inviteCode: String,

    maxPlayers: {
      type: Number,
      min: 2,
      required: true,
    },

    players: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        skill: {
          type: String,
          enum: ["beginner", "intermediate", "advanced"],
          default: "beginner",
        },
      },
    ],

    teams: {
      teamA: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
      teamB: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    },

    status: {
      type: String,
      enum: ["open", "full", "ongoing", "completed"],
      default: "open",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Match", matchSchema);