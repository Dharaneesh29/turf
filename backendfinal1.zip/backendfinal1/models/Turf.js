
const mongoose = require("mongoose");

const turfSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    sportType: { type: [String], default: [] },
    turfSize: String,
    length: Number,
    width: Number,
    maxCapacity: Number,
    description: String,
    amenities: [String],
    address: String,
    city: String,
    state: String,
    pinCode: String,
    contactNumber: String,
    email: String,
    googleMapLink: String,
    weekdayPrice: Number,
    weekendPrice: Number,
    minBookingDuration: String,
    weekdayOpen: String,
    weekdayClose: String,
    weekendOpen: String,
    weekendClose: String,
    images: [String],
    location: {
      type: {
        type: String,
        enum: ["Point"],
        default: undefined, // ✅ prevents partial GeoJSON from being saved
      },
      coordinates: {
        type: [Number], // [lng, lat]
        default: undefined, // ✅ prevents empty array from breaking 2dsphere index
      },
    },
    averageRating: { type: Number, default: 0 },
    ratingCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// ✅ sparse: true skips documents that have no location field
turfSchema.index({ location: "2dsphere" }, { sparse: true });

module.exports = mongoose.model("Turf", turfSchema);

