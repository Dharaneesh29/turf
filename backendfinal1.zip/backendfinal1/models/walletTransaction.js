const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  user:    { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  amount:  { type: Number },
  type:    { type: String, enum: ["credit", "debit"] },
  reason:  { type: String },
  booking: { type: mongoose.Schema.Types.ObjectId, ref: "Booking" },
}, { timestamps: true });
module.exports = mongoose.model("WalletTransaction", schema);