require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const cron = require("node-cron")
const Booking = require("./models/Booking");

connectDB();

const app = express();
app.use(cors());
app.use(express.json());

// ROUTES
app.use("/api/matches", require("./routes/matchRoutes"));
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/admin", require("./routes/adminRoutes"));
app.use("/uploads", express.static("uploads"));
app.use("/api/turfs", require("./routes/turfRoutes"));
app.use("/api/bookings", require("./routes/bookingRoutes"));
app.use("/api/slots", require("./routes/slotRoutes"));
app.use("/api/messages", require("./routes/messageRoutes")); // ✅ IMPORTANT
app.use("/api/memberships", require("./routes/membershipRoutes"));
app.use("/api/reviews", require("./routes/reviewRoutes"));
app.use("/api/notifications", require("./routes/NotificationRoutes"))


/* -------------------------------------------------------
   🔥 SOCKET.IO SETUP
-------------------------------------------------------- */
const { Server } = require("socket.io");
const Message = require("./models/Message"); // ✅ ADD THIS

const server = app.listen(5000, () => {
  console.log("✅ Backend running on port 5000");
});

const io = new Server(server, {
  cors: {
    origin: "*",
  },
});

/* -------------------------------------------------------
   🔥 SOCKET EVENTS
-------------------------------------------------------- */
io.on("connection", (socket) => {
  console.log("🔌 Socket connected:", socket.id);

  /* ✅ JOIN MATCH ROOM */
  socket.on("join-match", (matchId) => {
    socket.join(`match:${matchId}`);
    console.log(`👥 Socket ${socket.id} joined match:${matchId}`);
  });

  /* ✅ SEND + SAVE MATCH CHAT MESSAGE */
  socket.on("send-message", async ({ matchId, user, message }) => {
    try {
      const savedMessage = await Message.create({
        match: matchId,
        senderName: user,
        message,
      });

      io.to(`match:${matchId}`).emit("receive-message", {
        _id: savedMessage._id,
        user: savedMessage.senderName,
        message: savedMessage.message,
        createdAt: savedMessage.createdAt,
      });
    } catch (err) {
      console.error("❌ Chat save failed:", err.message);
    }
  });

  socket.on("disconnect", () => {
    console.log("❌ Socket disconnected:", socket.id);
  });
});

// ✅ Export io for controllers (slots etc.)
module.exports.io = io;


// Runs every day at midnight
cron.schedule("0 0 * * *", async () => {
  try {
    const today = new Date().toISOString().split("T")[0]; // "2026-04-25"
   
    const result = await Booking.updateMany(
      {
        status: "confirmed",
        date: { $lt: today }, // booking date is before today
      },
      {
        $set: { status: "completed" }
      }
    );
   
    console.log(`✅ Auto-completed ${result.modifiedCount} bookings`);
  } catch (err) {
    console.error("❌ Auto-complete cron failed:", err);
  }
});
 
