const User = require("../models/User");

/**
 * ✅ CREDIT MONEY TO WALLET
 */
exports.addToWallet = async (userId, amount, description = "Wallet credit") => {
  // ✅ Validate amount
  amount = Number(amount);
  if (!amount || amount <= 0) {
    throw new Error("Invalid wallet credit amount");
  }

  // ✅ Fetch user
  const user = await User.findById(userId);
  if (!user) {
    throw new Error("User not found for wallet credit");
  }

  // ✅ Update wallet
  user.walletBalance += amount;
  user.walletHistory.push({
    amount,
    type: "credit",
    description,
    date: new Date(),
  });

  await user.save();

  return user.walletBalance;
};

/**
 * ✅ DEBIT MONEY FROM WALLET
 */
exports.deductFromWallet = async (userId, amount, description = "Wallet debit") => {
  // ✅ Validate amount
  amount = Number(amount);
  if (!amount || amount <= 0) {
    throw new Error("Invalid wallet debit amount");
  }

  // ✅ Fetch user
  const user = await User.findById(userId);
  if (!user) {
    throw new Error("User not found for wallet debit");
  }

  // ✅ Balance check
  if (user.walletBalance < amount) {
    throw new Error("Insufficient wallet balance");
  }

  // ✅ Update wallet
  user.walletBalance -= amount;
  user.walletHistory.push({
    amount,
    type: "debit",
    description,
    date: new Date(),
  });

  await user.save();

  return user.walletBalance;
};
