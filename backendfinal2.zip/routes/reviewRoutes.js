const express = require("express");
const router  = express.Router();
const Review  = require("../models/Review");
const auth    = require("../middleware/authMiddleware");
const admin=require("../middleware/adminMiddleware");

// GET all reviews for a turf
router.get("/:turfId", async (req, res) => {
  try {
    const reviews = await Review.find({ turf: req.params.turfId })
      .populate("user", "name")
      .sort({ createdAt: -1 });
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST submit a review
router.post("/:turfId", auth, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const existing = await Review.findOne({
      turf: req.params.turfId,
      user: req.user.id,
    });
    if (existing) {
      return res.status(400).json({ message: "You have already reviewed this turf" });
    }
    const review = await Review.create({
      turf: req.params.turfId,
      user: req.user.id,
      rating,
      comment,
    });
    const populated = await review.populate("user", "name");
    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get("/admin/all", auth, admin, async(req, res) => {
    try{
    const reviews = await Review.find()
    .populate("user", "name")
    .populate("turf", "name")
    .sort({ createdAt : -1 })
    res.json(reviews)
    } catch (err) {
        res.status(500).json({message: err.message})
    }
})

module.exports = router;