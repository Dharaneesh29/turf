const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const admin = require("../middleware/adminMiddleware");
const upload = require("../middleware/upload"); // ✅ ADD THIS


const {
  addTurf,
  getTurfs,
  updateTurf,
  deleteTurf,
  getBookings,
  getUsers,
  updateUsers,
  deleteUsers,
  updateBookingStatus,
  deleteBooking,
} = require("../controllers/adminController");


// ✅ ADD TURF with IMAGE


router.post(
  "/turf",
  auth,
  upload.array("images", 10), // 🔴 MUST be "images"
  addTurf
);


// ✅ GET ALL TURFS
router.get("/turf", auth, admin, getTurfs);

router.put("/turf/:id", auth, admin, upload.array("image",10), updateTurf)

// ✅ DELETE TURF
router.delete("/turf/:id", auth, admin, deleteTurf);

// ✅ VIEW BOOKINGS
router.get("/bookings", auth, admin, getBookings);

router.put("/bookings/:id", auth, admin, updateBookingStatus)

router.delete("/bookings/:id", auth, admin, deleteBooking)

router.get("/users", auth, admin, getUsers)

router.put("/users/:id", auth, admin, updateUsers)

router.delete("/users/:id", auth, admin, deleteUsers)

module.exports = router;
