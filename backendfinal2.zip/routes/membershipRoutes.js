const router = require("express").Router();
const auth = require("../middleware/authMiddleware");
const admin = require("../middleware/adminMiddleware");
const controller = require("../controllers/membershipController");

// ✅ Public / user routes
router.get("/plans", controller.getPlans);
router.get("/my", auth, controller.getMyMembership);
router.post("/activate", auth, controller.activateMembership);

// ✅ Admin routes (FIXED ✅)
router.post("/plans", auth, admin, controller.createPlan);
router.put("/plans/:id", auth, admin, controller.updatePlan);

router.delete("/plans/:id", auth, admin, controller.deletePlan)


module.exports = router;