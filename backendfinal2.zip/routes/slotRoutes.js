const express = require("express");
const router = express.Router();
const Booking = require("../models/Booking");
const Turf = require("../models/Turf");

// Generate hourly slots
function generateSlots(open, close) {
  const slots = [];
  let hour = parseInt(open.split(":")[0], 10);
  const end = parseInt(close.split(":")[0], 10);

  while (hour < end) {
    const start = hour.toString().padStart(2, "0") + ":00";
    const endTime = (hour + 1).toString().padStart(2, "0") + ":00";
    slots.push({ start, end: endTime });
    hour++;
  }
  return slots;
}

router.get("/:turfId/:date", async (req, res) => {
  try {
    const { turfId, date } = req.params;

    // ✅ NORMALIZE DATE HERE (INSIDE REQUEST)
    const normalizedDate = new Date(date).toISOString().split("T")[0];

    const turf = await Turf.findById(turfId);
    if (!turf) {
      return res.status(404).json({ message: "Turf not found" });
    }

    const isWeekend = [0, 6].includes(new Date(normalizedDate).getDay());
    const open = isWeekend ? turf.weekendOpen : turf.weekdayOpen;
    const close = isWeekend ? turf.weekendClose : turf.weekdayClose;

    const allSlots = generateSlots(open, close);

    // ✅ Find bookings using normalized date
    const bookings = await Booking.find({
      turf: turfId,
      date: normalizedDate,
    });

    const bookedSlots = bookings.map((b) => b.timeSlot);

    const result = allSlots.map((slot) => {
      const label = `${slot.start} - ${slot.end}`;
      return {
        slot: label,
        available: !bookedSlots.includes(label),
      };
    });

    res.json(result);
  } catch (err) {
    console.error("slotRoutes error:", err.message);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;