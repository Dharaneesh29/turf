const express = require("express");
const router = express.Router();
const { register, login } = require("../controllers/authController");
const auth = require("../middleware/authMiddleware");
const User = require("../models/User")
const bcrypt =  require("bcrypt")
const WalletTransaction = require("../models/walletTransaction");
 
router.post("/register", register);
router.post("/login", login);
 
router.get("/profile", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
 
router.put("/profile", auth, async (req, res) => {
  try {
    const { name, phone, dob } = req.body;
 
    const updated = await User.findByIdAndUpdate(
      req.user.id,
      { name, phone, dob },
      { new: true, runValidators: true }
    ).select("-password");
 
    res.json({ success: true, user: updated });
  } catch (err) {
    res.status(500).json({ message: "Update failed" });
  }
});
 
router.put("/change-password", auth, async(req, res) => {
  try{
    const {currentPassword, newPassword} = req.body
    const user = await User.findById(req.user.id)
    const isMatch = await bcrypt.compare(currentPassword, user.password)
    if(!isMatch) return res.status(400).json({message: "Current password is incorrect"})
 
    user.password = await bcrypt.hash(newPassword, 10)
    await user.save()
    res.json({message: "Password changed susscessfully"})
  }catch (err) {
    res.status(500).json({message: err.message})
  }
})
 
router.delete("/account", auth, async(req, res) => {
  try{
    await User.findByIdAndDelete(req.user.id)
    res.json({message: "Account deleted"})
  } catch (err) {
    res.status(500).json({message: err.message})
  }
})
 
router.get("/favourites", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate("favourites");
    res.json(user.favourites || []);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
 
// TOGGLE favourite (add if not exists, remove if exists)
router.post("/favourites/:turfId", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const turfId = req.params.turfId;
    const index = user.favourites.findIndex(id => id.toString() === turfId);
 
    if (index === -1) {
      user.favourites.push(turfId); // add
    } else {
      user.favourites.splice(index, 1); // remove
    }
 
    await user.save();
    res.json({ favourites: user.favourites, isFavourite: index === -1 });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});



// Get wallet balance + transactions
router.get("/wallet", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("walletBalance");
    const transactions = await WalletTransaction.find({ user: req.user.id })
      .sort({ createdAt: -1 }).limit(10);
    res.json({ balance: user.walletBalance, transactions });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
 
module.exports = router;
 