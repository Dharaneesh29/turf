const router = require("express").Router();
const auth = require("../middleware/authMiddleware");
const ctrl = require("../controllers/matchController");

// ======================
// CREATE & LIST MATCHES
// ======================
router.post("/", auth, ctrl.createMatch);
router.get("/", ctrl.getMatches);

// ======================
// ✅ MY MATCHES (REGISTERED ONLY)
// MUST BE BEFORE :matchId
// ======================
router.get("/my-matches", auth, ctrl.getMyMatches);

// ======================
// JOIN BY INVITE
// ======================
router.post(
  "/join-by-invite/:inviteCode",
  auth,
  ctrl.joinByInvite
);

// ======================
// MATCH DETAILS
// ======================
router.get("/:matchId", auth, ctrl.getMatchById);

// ======================
// MATCH ACTIONS
// ======================
router.post("/:matchId/join", auth, ctrl.joinMatch);
router.post("/:matchId/leave", auth, ctrl.leaveMatch);

module.exports = router;