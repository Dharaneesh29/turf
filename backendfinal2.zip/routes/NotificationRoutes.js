const express = require("express")
const router = express.Router()
const auth = require("../middleware/authMiddleware")
 
const {
    getNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAll,
} = require("../controllers/notificationController")
 
router.get("/", auth, getNotifications)
router.put("/:id/read", auth, markAsRead)
router.put("/read-all", auth, markAllAsRead)
router.delete("/:id", auth, deleteNotification)
router.delete("/", auth, clearAll)
 
module.exports=router;