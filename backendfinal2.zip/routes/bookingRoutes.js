const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const { createBooking, getUserBookings } = require("../controllers/bookingController");
const User = require("../models/User")
const Booking = require("../models/Booking");
const WalletTransaction = require("../models/walletTransaction");
 
// ✅ User booking
router.post("/", auth, createBooking);
router.get("/my", auth, getUserBookings)
 
router.post("/book", auth, async (req, res) => {
 
  try {
    const user = await User.findById(req.user.id);
    let { amount } = req.body;
    // Convert amount to number (IMPORTANT)
    amount = Number(amount);
    // Check birthday month discount
    if (user?.dob) {
      const dobMonth = new Date(user.dob).getMonth(); // 0–11
      const currentMonth = new Date().getMonth();
      if (dobMonth === currentMonth) {
        amount = amount * 0.9; // 10% discount
      }
    }
 
    const booking = new Booking({
      ...req.body,
      amount,
      user: req.user.id,
    });
 
    await booking.save();
    res.status(200).json({
      success: true,
      message: "Booking successful",
      booking,
    });
  } catch (error) {
 
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});
 
router.get("/user/completed/:turfId", auth, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      user: req.user.id,
      turf: req.params.turfId,
      status: { $in: ["confirmed", "completed"] },
    });
    res.json({ canReview: !!booking });
  } catch (err) {
    res.status(500).json({ canReview: false });
  }
});
 
 
router.put("/:id/cancel", auth, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ message: "Booking not found" });

    // Calculate refund
    const bookingDate = new Date(booking.date);
    const hoursLeft   = (bookingDate - new Date()) / (1000 * 60 * 60);

    let refundAmount = 0;
    if (hoursLeft >= 24)       refundAmount = booking.totalAmount;       // 100%
    else if (hoursLeft >= 2)   refundAmount = booking.totalAmount * 0.5; // 50%
    // < 2 hours = 0%

    booking.status = "cancelled";
    booking.cancellationReason = req.body.reason;
    await booking.save();

    // Credit wallet if paid booking
    if (refundAmount > 0 && booking.paymentStatus === "paid") {
      await User.findByIdAndUpdate(req.user.id, {
        $inc: { walletBalance: refundAmount }
      });
      await WalletTransaction.create({
        user:    req.user.id,
        amount:  refundAmount,
        type:    "credit",
        reason:  "Booking cancellation refund",
        booking: booking._id,
      });
    }

    res.json({ booking, refundAmount });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
 
module.exports = router;
 