const router = require("express").Router();
const Message = require("../models/Message");
const auth = require("../middleware/authMiddleware");

router.get("/:matchId", auth, async (req, res) => {
  const messages = await Message.find({ match: req.params.matchId })
    .sort({ createdAt: 1 });

  res.json(messages);
});

module.exports = router;