const express = require("express");
const router = express.Router();
const multer = require("multer");

const {
  addTurf,
  updateTurf,
  deleteTurf,
  getTurfs,
  getTurfById,       // ✅ now from controller (no inline logic in routes)
  getNearbyTurfs,
} = require("../controllers/turfController");

/* ================= MULTER CONFIG ================= */
const upload = multer({
  dest: "uploads/turfs/",
});

/* ================= ADD TURF ================= */
router.post("/turf", upload.array("images", 10), addTurf);

/* ================= UPDATE TURF ================= */
router.put("/turf/:id", upload.array("images", 10), updateTurf);

/* ================= DELETE TURF ================= */
router.delete("/turf/:id", deleteTurf);

/* ================= GET NEARBY TURFS ================= */
// ✅ MUST come BEFORE "/:id" to avoid Express treating "nearby" as an id
// Example: /api/turfs/nearby?lat=12.9716&lng=77.5946&distance=5000
router.get("/nearby", getNearbyTurfs);

/* ================= GET ALL TURFS (WITH RATINGS) ================= */
// ✅ Moved aggregate logic into getTurfs controller — cleaner route file
router.get("/", getTurfs);

/* ================= GET SINGLE TURF BY ID ================= */
// ✅ MUST come AFTER /nearby
router.get("/:id", getTurfById);

module.exports = router;